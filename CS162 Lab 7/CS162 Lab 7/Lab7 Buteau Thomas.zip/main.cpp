/*********************************************************************************
** Program name: Lab 7
** Author: Thomas Buteau
** Date: 2-26-17
** Description: Main file for Lab 7. This program uses recursion to flip a string,
**				sum the items in an array, or return a triangle number.
**
*********************************************************************************/

#include "menu.hpp"

int main()
{
	
	menu();

	return 0;
}