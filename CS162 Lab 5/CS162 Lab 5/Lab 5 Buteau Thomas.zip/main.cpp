/*********************************************************************************
** Program name: Lab 4
** Author: Thomas Buteau
** Date: 2-12-17
** Description: Main file for Lab 4. This program uses recursion to flip a string,
**				sum the items in an array, or return a triangle number.
**
*********************************************************************************/
#include "menu.hpp"

int main()
{
	
	menu();

	return 0;
}