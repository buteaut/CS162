/*********************************************************************************
** Program name: Lab 9
** Author: Thomas Buteau
** Date: 3-12-17
** Description: Stack header file for Lab 9.
**
*********************************************************************************/

#ifndef STACK_HPP
#define STACK_HPP

#include <stack>

std::stack<char> palin;

#endif
