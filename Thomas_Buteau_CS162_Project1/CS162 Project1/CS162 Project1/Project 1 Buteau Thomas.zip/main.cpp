/*********************************************************************************
** Program name: Project1 (Main File)
** Author: Thomas Buteau
** Date: 1-16-17
** Description: Main file for Project1. Starts the Menu function.
**
*********************************************************************************/

#include "menu.hpp"

int main() {

	menu();
	
	return 0;
}